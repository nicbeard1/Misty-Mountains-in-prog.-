<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mistymountains";

$uname = $_POST["username"];
$pword = $_POST["password"];
// $email = $_POST["email"];

// echo $uname;
// echo $pword;
// echo $email;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// $sql = "INSERT INTO userdb (username,password)
// VALUES (?,?)";

$stmt = $conn->prepare("INSERT INTO userdb (username,password)
VALUES (?,?)");
$stmt->bind_param("ss",$uname ,$pword);
$stmt->execute();
$conn->close();

$header = "index.php";

header("location:".$header);
exit();
?>