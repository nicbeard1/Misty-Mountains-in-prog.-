<?php
// Start the session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Misty Mountains</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">Misty Mountains -- Chat Room</a>
                
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
                <div class="d-flex justify-content-center">
                    <div class="text-center">
                        <h1 class="mx-auto my-0 text-uppercase">Misty Mountains</h1>
                        <h2 class="text-white-50 mx-auto mt-2 mb-5">A simple chat room, allowing you to share messages and media</h2>
                        <a class="btn btn-primary" href="#about">Login</a>
                    </div>
                </div>
            </div>
        </header>

        <!-- login form-->
        <section class="projects-section bg-dark" id="">
            <section class="page-section cta">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <div class="cta-inner bg-faded text-center rounded">
                            <h2 class="section-heading mb-5">
                                <span class="section-heading-upper"> </span>
                                <!-- <span class="section-heading-lower">Rate My Cake</span> -->
                            </h2>
                            
                            <div style="display: inline-block; text-align: center;">
                                <form action="signup-php.php" method="post" enctype="multipart/form-data">

                                <label for="uname"><b>Username</b></label>
                                <input type="text" placeholder="Enter Username" name="username" required>
                                <br>
                                <label for="psw"><b>Password</b></label>
                                <input type="password" placeholder="Enter Password" name="password" required>
                                  <br>

                                  <input style="width:100%;" type="submit" value="create account" />
                                </form>
                            </div>
                            <?php  
                              if ((isset($_SESSION["error"])) && ($_SESSION["error"])){
                                echo $_SESSION["error"];
                                $_SESSION["error"] = "";

                              } 
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Login -->
        <?php
         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "mistymountains";
     
         // Create connection
         $conn = new mysqli($servername, $username, $password, $dbName);
         if ($conn->connect_error) {;
                 die();
         }
         $stmt = $conn->prepare("SELECT * FROM userdb");
         
        // ORDER BY review_id DESC

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                // $AIid = $row["id"];
                $user = $row["username"];
                $pass = $row["password"];

                $array = array("username", "password");
            
        }
        } else {
        $status = "loggedOut";
        $_SESSION['error'] = "Error: these details are incorrect. Please try again.";
        $_SESSION["status"] = $status;
        // header("location:index.php");
        $conn->close();
        }
        ?>

        <!-- <?php
        // Set session variables
        $_SESSION["username"] = $user;
        echo "Session variables are set.";
        ?> -->

        </section>
        
        <!-- Footer-->
        <footer class="footer bg-black small text-center text-white-50"><div class="container px-4 px-lg-5">Copyright &copy; Misty Mountains 2024</div></footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
